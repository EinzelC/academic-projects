#include "../../includes/packet.h"

// wires the neighbor-discovery logic to its timer and radio services.
configuration NeighborDiscoveryC {
   provides interface NeighborDiscovery;
}
implementation {
   components NeighborDiscoveryP;
   components new TimerMilliC() as BeaconTimer;
   components new SimpleSendC(AM_PACK) as BeaconSender;
   components new AMReceiverC(AM_PACK) as BeaconReceiver;
   NeighborDiscovery = NeighborDiscoveryP.NeighborDiscovery;
   NeighborDiscoveryP.BeaconTimer -> BeaconTimer;
   NeighborDiscoveryP.Sender -> BeaconSender;
   NeighborDiscoveryP.Receive -> BeaconReceiver;
}
