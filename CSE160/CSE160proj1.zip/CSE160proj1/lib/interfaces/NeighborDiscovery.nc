// start beacons and print the current table.
interface NeighborDiscovery {
   command void start();
   command void print();
}
