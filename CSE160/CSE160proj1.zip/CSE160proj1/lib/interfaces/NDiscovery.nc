interface NDiscovery {
    command void start();
    command voidprintNeighbors();
}